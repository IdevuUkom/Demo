﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp1.Classess;

namespace WpfApp1.Views
{
    /// <summary>
    /// Логика взаимодействия для SignIn.xaml
    /// </summary>
    public partial class SignIn : Page
    {
        public SignIn()
        {
            InitializeComponent();
        }

        private void BtnSignIn_Click(object sender, RoutedEventArgs e)
        {
            var CurrentUser = AppData.db.Users.FirstOrDefault(u => u.Login == Txblogin.Text && u.Password == TxbPassword.Text);
            if (CurrentUser != null)
            {
                NavigationService.Navigate(new DataPage());
            }
            else
            {
                MessageBox.Show("Неправильный логин или пароль");
            }
            if (CurrentUser.IDRole == 1)
            {
                NavigationService.Navigate(new DataPage());
            }

            if (CurrentUser.IDRole == 2)
            {
                NavigationService.Navigate(new WelcomePage());
            }
        }

        private void BtnToReg_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new RegPage());
        }
    }
}
