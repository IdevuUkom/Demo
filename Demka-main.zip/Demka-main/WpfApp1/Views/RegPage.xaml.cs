﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp1.Classess;
using WpfApp1.Modelss;

namespace WpfApp1.Views
{
    /// <summary>
    /// Логика взаимодействия для RegPage.xaml
    /// </summary>
    public partial class RegPage : Page
    {
        public RegPage()
        {
            InitializeComponent();
        }

        private void BtnBackToAuth_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void Reg_Click(object sender, RoutedEventArgs e)
        {
            if (AppData.db.Users.Count(u => u.Login == TxbRegLogin.Text) > 0)
            {
                MessageBox.Show("Такой пользователь уже есть");
                return;
            }
            
            if (AppData.db.Users.Count(u => u.Email == TxbRegEmail.Text) > 0)
            {
                MessageBox.Show("Пользователь с такой почтой уже есть");
                return;
            }

            Users People = new Users();
            
            People.Login = TxbRegLogin.Text;
            People.Password = TxbRegPassword.Text;
            People.Email = TxbRegEmail.Text;
            People.IDRole = 2;

            AppData.db.Users.Add(People);
            AppData.db.SaveChanges();
            MessageBox.Show("Регистрация успешна!");
            NavigationService.GoBack();
            }
        }
    }

