﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1.Modelss;

namespace WpfApp1.Classess
{
    public static class AppData
    {
        public static dbEntities db = new dbEntities();
    }
}
